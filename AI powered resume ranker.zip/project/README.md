# AI-Powered Resume Ranking Application

A comprehensive full-stack application that uses Natural Language Processing (NLP) to intelligently rank resumes against job descriptions, helping HR professionals streamline their candidate screening process.

## 🚀 Features

- **Drag & Drop Resume Upload**: Easy PDF resume upload with support for multiple files
- **AI-Powered Text Analysis**: Advanced NLP using TF-IDF vectorization and cosine similarity
- **Intelligent Ranking**: Automatic ranking of resumes based on job description match
- **Beautiful Dashboard**: Modern, responsive UI with real-time statistics
- **Resume Viewer**: Built-in text extraction and viewing capabilities
- **Downloadable Reports**: Generate and download ranking reports in JSON format
- **Real-time Processing**: Live updates and status indicators

## 🛠️ Tech Stack

### Backend
- **Node.js** with Express.js
- **Natural.js** for NLP processing and TF-IDF vectorization
- **pdf-parse** for PDF text extraction
- **Multer** for file upload handling
- **CORS** for cross-origin requests

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Lucide React** for icons
- **Axios** for API communication

### NLP Pipeline
- **Text Preprocessing**: Tokenization, stopword removal, stemming
- **TF-IDF Vectorization**: Term frequency-inverse document frequency
- **Cosine Similarity**: Mathematical similarity scoring
- **Ranking Algorithm**: Intelligent candidate ranking

## 📋 Prerequisites

- Node.js (v16 or higher)
- npm or yarn package manager

## 🚀 Quick Start

1. **Clone and Install Dependencies**
   ```bash
   npm install
   ```

2. **Start the Application**
   ```bash
   npm run dev
   ```

   This will start both the frontend (port 3000) and backend (port 3001) servers concurrently.

3. **Access the Application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:3001

## 📖 How to Use

1. **Upload Resumes**: Drag and drop PDF resumes or click to browse (max 10 files)
2. **Enter Job Description**: Paste or type the job description you want to match against
3. **Rank Resumes**: Click "Rank Resumes" to start the AI analysis
4. **View Results**: See ranked candidates with match percentages
5. **Review Details**: Click "View" to see extracted resume content
6. **Download Report**: Generate a downloadable ranking report

## 🧠 How It Works

### NLP Processing Pipeline

1. **Text Extraction**: PDF content is extracted using pdf-parse
2. **Preprocessing**: 
   - Convert to lowercase
   - Remove special characters
   - Tokenization using Natural.js
   - Remove stopwords
   - Apply Porter stemming
3. **Vectorization**: Create TF-IDF vectors for job description and resumes
4. **Similarity Calculation**: Compute cosine similarity between vectors
5. **Ranking**: Sort candidates by similarity score

### Scoring Algorithm

The application uses cosine similarity to measure the angle between TF-IDF vectors:

```
similarity = (A · B) / (||A|| × ||B||)
```

Where A is the job description vector and B is the resume vector.

## 🎯 API Endpoints

- `POST /api/upload-resumes` - Upload multiple PDF resumes
- `POST /api/rank-resumes` - Rank resumes against job description
- `GET /api/resume/:id` - Get specific resume content
- `DELETE /api/resumes` - Clear all uploaded resumes

## 🎨 UI Components

- **Header**: Branding and status indicators
- **StatsCard**: Real-time statistics dashboard
- **FileUpload**: Drag-and-drop resume upload
- **JobDescriptionInput**: Job description input with sample data
- **RankingResults**: Ranked results with detailed view

## 📊 Sample Data

The application includes sample job descriptions for testing. You can use the "Use sample job description" button to quickly test the ranking functionality.

## 🔧 Configuration

### File Upload Limits
- Maximum files: 10 PDFs
- File types: PDF only
- Storage: Local filesystem (uploads directory)

### NLP Settings
- Tokenizer: Word tokenizer
- Stemmer: Porter stemmer
- Stopwords: English stopwords from Natural.js
- Similarity: Cosine similarity

## 🚀 Production Deployment

For production deployment:

1. Set environment variables for file storage
2. Configure proper CORS settings
3. Add authentication and authorization
4. Implement rate limiting
5. Add logging and monitoring
6. Use cloud storage for file uploads

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Troubleshooting

### Common Issues

1. **Server not starting**: Ensure Node.js is installed and ports 3000/3001 are available
2. **File upload fails**: Check file size limits and ensure PDFs are valid
3. **Ranking not working**: Verify job description is provided and resumes are uploaded
4. **CORS errors**: Ensure backend server is running on port 3001

### Support

For issues and questions, please check the console logs for detailed error messages.