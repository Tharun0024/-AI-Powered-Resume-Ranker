import express from 'express';
import multer from 'multer';
import pdfParse from 'pdf-parse';
import natural from 'natural';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Create uploads directory if it doesn't exist
const uploadsDir = 'uploads';
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + '.pdf');
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed!'), false);
    }
  }
});

// NLP utilities
const TfIdf = natural.TfIdf;
const tokenizer = new natural.WordTokenizer();
const stemmer = natural.PorterStemmer;

// Text preprocessing function
function preprocessText(text) {
  // Convert to lowercase and remove special characters
  const cleaned = text.toLowerCase().replace(/[^\w\s]/g, ' ');
  
  // Tokenize
  const tokens = tokenizer.tokenize(cleaned);
  
  // Remove stopwords and stem
  const stopwords = natural.stopwords;
  const processedTokens = tokens
    .filter(token => token.length > 2 && !stopwords.includes(token))
    .map(token => stemmer.stem(token));
  
  return processedTokens.join(' ');
}

// Calculate cosine similarity
function cosineSimilarity(vecA, vecB) {
  const dotProduct = vecA.reduce((sum, a, i) => sum + a * vecB[i], 0);
  const magnitudeA = Math.sqrt(vecA.reduce((sum, a) => sum + a * a, 0));
  const magnitudeB = Math.sqrt(vecB.reduce((sum, b) => sum + b * b, 0));
  
  if (magnitudeA === 0 || magnitudeB === 0) return 0;
  return dotProduct / (magnitudeA * magnitudeB);
}

// Store processed resumes
let processedResumes = [];

// Routes
app.post('/api/upload-resumes', upload.array('resumes', 10), async (req, res) => {
  try {
    const files = req.files;
    const resumeData = [];

    for (const file of files) {
      try {
        const dataBuffer = fs.readFileSync(file.path);
        const pdfData = await pdfParse(dataBuffer);
        const extractedText = pdfData.text;
        const processedText = preprocessText(extractedText);

        resumeData.push({
          id: file.filename,
          originalName: file.originalname,
          filePath: file.path,
          extractedText,
          processedText,
          uploadTime: new Date().toISOString()
        });
      } catch (error) {
        console.error(`Error processing ${file.originalname}:`, error);
      }
    }

    processedResumes = resumeData;
    
    res.json({
      success: true,
      message: `Successfully processed ${resumeData.length} resumes`,
      resumes: resumeData.map(r => ({
        id: r.id,
        originalName: r.originalName,
        uploadTime: r.uploadTime,
        textLength: r.extractedText.length
      }))
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/rank-resumes', (req, res) => {
  try {
    const { jobDescription } = req.body;
    
    if (!jobDescription || processedResumes.length === 0) {
      return res.status(400).json({ 
        success: false, 
        error: 'Job description required and resumes must be uploaded first' 
      });
    }

    const processedJobDesc = preprocessText(jobDescription);
    
    // Create TF-IDF vectors
    const tfidf = new TfIdf();
    
    // Add job description and all resumes to TF-IDF
    tfidf.addDocument(processedJobDesc);
    processedResumes.forEach(resume => {
      tfidf.addDocument(resume.processedText);
    });

    // Get job description vector (first document)
    const jobVector = [];
    tfidf.listTerms(0).forEach(item => {
      jobVector.push(item.tfidf);
    });

    // Calculate similarity scores for each resume
    const rankedResumes = processedResumes.map((resume, index) => {
      const resumeVector = [];
      tfidf.listTerms(index + 1).forEach(item => {
        resumeVector.push(item.tfidf);
      });

      // Ensure vectors have the same length
      const maxLength = Math.max(jobVector.length, resumeVector.length);
      const paddedJobVector = [...jobVector, ...Array(maxLength - jobVector.length).fill(0)];
      const paddedResumeVector = [...resumeVector, ...Array(maxLength - resumeVector.length).fill(0)];

      const similarity = cosineSimilarity(paddedJobVector, paddedResumeVector);
      const score = Math.round(similarity * 100);

      return {
        ...resume,
        similarityScore: similarity,
        matchPercentage: score,
        rank: 0 // Will be set after sorting
      };
    });

    // Sort by similarity score (descending)
    rankedResumes.sort((a, b) => b.similarityScore - a.similarityScore);
    
    // Assign ranks
    rankedResumes.forEach((resume, index) => {
      resume.rank = index + 1;
    });

    res.json({
      success: true,
      jobDescription,
      totalResumes: rankedResumes.length,
      rankings: rankedResumes.map(r => ({
        id: r.id,
        originalName: r.originalName,
        rank: r.rank,
        matchPercentage: r.matchPercentage,
        uploadTime: r.uploadTime,
        textLength: r.extractedText.length
      })),
      detailedResults: rankedResumes
    });
  } catch (error) {
    console.error('Ranking error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/resume/:id', (req, res) => {
  try {
    const resume = processedResumes.find(r => r.id === req.params.id);
    if (!resume) {
      return res.status(404).json({ success: false, error: 'Resume not found' });
    }
    
    res.json({
      success: true,
      resume: {
        id: resume.id,
        originalName: resume.originalName,
        extractedText: resume.extractedText,
        uploadTime: resume.uploadTime
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/resumes', (req, res) => {
  try {
    // Delete uploaded files
    processedResumes.forEach(resume => {
      if (fs.existsSync(resume.filePath)) {
        fs.unlinkSync(resume.filePath);
      }
    });
    
    processedResumes = [];
    
    res.json({ success: true, message: 'All resumes cleared' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Resume Ranking Server running on http://localhost:${PORT}`);
});