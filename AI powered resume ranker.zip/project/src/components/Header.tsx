import React from 'react';
import { Brain, Zap } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
              <Brain className="text-white" size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">AI Resume Ranker</h1>
              <p className="text-sm text-gray-600">Intelligent candidate screening powered by NLP</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 px-3 py-1 bg-gradient-to-r from-green-100 to-blue-100 rounded-full">
            <Zap className="text-green-600" size={16} />
            <span className="text-sm font-medium text-gray-700">AI Powered</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;