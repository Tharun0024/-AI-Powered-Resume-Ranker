import React, { useState } from 'react';
import { Search, Briefcase, AlertCircle, CheckCircle } from 'lucide-react';

interface Resume {
  id: string;
  originalName: string;
  uploadTime: string;
  textLength: number;
}

interface RankedResume extends Resume {
  rank: number;
  matchPercentage: number;
}

interface RankingData {
  success: boolean;
  jobDescription: string;
  totalResumes: number;
  rankings: RankedResume[];
}

interface JobDescriptionInputProps {
  jobDescription: string;
  setJobDescription: (desc: string) => void;
  resumes: Resume[];
  onRankingComplete: (data: RankingData) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

const JobDescriptionInput: React.FC<JobDescriptionInputProps> = ({
  jobDescription,
  setJobDescription,
  resumes,
  onRankingComplete,
  isLoading,
  setIsLoading
}) => {
  const [rankingStatus, setRankingStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [rankingMessage, setRankingMessage] = useState('');

  const handleRanking = async () => {
    if (!jobDescription.trim()) {
      setRankingStatus('error');
      setRankingMessage('Please enter a job description');
      return;
    }

    if (resumes.length === 0) {
      setRankingStatus('error');
      setRankingMessage('Please upload resumes first');
      return;
    }

    setIsLoading(true);
    setRankingStatus('idle');

    try {
      const response = await fetch('http://localhost:3001/api/rank-resumes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ jobDescription }),
      });

      const data = await response.json();

      if (data.success) {
        onRankingComplete(data);
        setRankingStatus('success');
        setRankingMessage(`Successfully ranked ${data.totalResumes} resumes`);
      } else {
        setRankingStatus('error');
        setRankingMessage(data.error || 'Ranking failed');
      }
    } catch (error) {
      setRankingStatus('error');
      setRankingMessage('Network error. Please ensure the server is running.');
    } finally {
      setIsLoading(false);
    }
  };

  const sampleJobDescription = `We are seeking a Senior Software Engineer with 5+ years of experience in full-stack development. 

Key Requirements:
• Proficiency in JavaScript, React, Node.js
• Experience with cloud platforms (AWS, Azure)
• Strong knowledge of databases (SQL, NoSQL)
• Familiarity with DevOps practices and CI/CD
• Excellent problem-solving and communication skills
• Bachelor's degree in Computer Science or related field

Responsibilities:
• Design and develop scalable web applications
• Collaborate with cross-functional teams
• Mentor junior developers
• Participate in code reviews and architecture decisions
• Ensure high-quality code and best practices`;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
        <Briefcase size={20} />
        Job Description
      </h2>
      
      <div className="space-y-4">
        <div>
          <textarea
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            placeholder="Enter the job description here..."
            className="w-full h-40 p-3 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            disabled={isLoading}
          />
          <div className="flex justify-between items-center mt-2">
            <p className="text-xs text-gray-500">
              {jobDescription.length} characters
            </p>
            <button
              onClick={() => setJobDescription(sampleJobDescription)}
              className="text-xs text-blue-600 hover:text-blue-700 underline"
              disabled={isLoading}
            >
              Use sample job description
            </button>
          </div>
        </div>

        <button
          onClick={handleRanking}
          disabled={isLoading || resumes.length === 0 || !jobDescription.trim()}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          <Search size={20} />
          {isLoading ? 'Ranking Resumes...' : 'Rank Resumes'}
        </button>

        {rankingStatus !== 'idle' && (
          <div className={`p-3 rounded-lg flex items-center gap-2 ${
            rankingStatus === 'success' 
              ? 'bg-green-50 text-green-700 border border-green-200' 
              : 'bg-red-50 text-red-700 border border-red-200'
          }`}>
            {rankingStatus === 'success' ? (
              <CheckCircle size={16} />
            ) : (
              <AlertCircle size={16} />
            )}
            <span className="text-sm font-medium">{rankingMessage}</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default JobDescriptionInput;