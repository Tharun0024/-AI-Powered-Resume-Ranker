import React, { useCallback, useState } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle } from 'lucide-react';

interface Resume {
  id: string;
  originalName: string;
  uploadTime: string;
  textLength: number;
}

interface FileUploadProps {
  onResumesUploaded: (resumes: Resume[]) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onResumesUploaded, isLoading, setIsLoading }) => {
  const [dragActive, setDragActive] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [uploadMessage, setUploadMessage] = useState('');

  const handleFiles = async (files: FileList) => {
    const pdfFiles = Array.from(files).filter(file => file.type === 'application/pdf');
    
    if (pdfFiles.length === 0) {
      setUploadStatus('error');
      setUploadMessage('Please select PDF files only');
      return;
    }

    if (pdfFiles.length > 10) {
      setUploadStatus('error');
      setUploadMessage('Maximum 10 files allowed');
      return;
    }

    setIsLoading(true);
    setUploadStatus('idle');

    const formData = new FormData();
    pdfFiles.forEach(file => {
      formData.append('resumes', file);
    });

    try {
      const response = await fetch('http://localhost:3001/api/upload-resumes', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (data.success) {
        onResumesUploaded(data.resumes);
        setUploadStatus('success');
        setUploadMessage(`Successfully uploaded ${data.resumes.length} resume${data.resumes.length !== 1 ? 's' : ''}`);
      } else {
        setUploadStatus('error');
        setUploadMessage(data.error || 'Upload failed');
      }
    } catch (error) {
      setUploadStatus('error');
      setUploadMessage('Network error. Please ensure the server is running.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
        <Upload size={20} />
        Upload Resumes
      </h2>
      
      <div
        className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
          dragActive
            ? 'border-blue-400 bg-blue-50'
            : 'border-gray-300 hover:border-gray-400'
        } ${isLoading ? 'opacity-50 pointer-events-none' : ''}`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <input
          type="file"
          multiple
          accept=".pdf"
          onChange={handleChange}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          disabled={isLoading}
        />
        
        <div className="space-y-4">
          <div className="mx-auto w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
            <FileText className="text-gray-400" size={24} />
          </div>
          
          <div>
            <p className="text-lg font-medium text-gray-700">
              {isLoading ? 'Processing...' : 'Drop PDF files here'}
            </p>
            <p className="text-sm text-gray-500 mt-1">
              or click to browse (max 10 files)
            </p>
          </div>
        </div>
      </div>

      {uploadStatus !== 'idle' && (
        <div className={`mt-4 p-3 rounded-lg flex items-center gap-2 ${
          uploadStatus === 'success' 
            ? 'bg-green-50 text-green-700 border border-green-200' 
            : 'bg-red-50 text-red-700 border border-red-200'
        }`}>
          {uploadStatus === 'success' ? (
            <CheckCircle size={16} />
          ) : (
            <AlertCircle size={16} />
          )}
          <span className="text-sm font-medium">{uploadMessage}</span>
        </div>
      )}
    </div>
  );
};

export default FileUpload;