import React, { useState } from 'react';
import { Trophy, Medal, Award, Eye, Download, FileText } from 'lucide-react';

interface RankedResume {
  id: string;
  originalName: string;
  rank: number;
  matchPercentage: number;
  uploadTime: string;
  textLength: number;
}

interface RankingData {
  success: boolean;
  jobDescription: string;
  totalResumes: number;
  rankings: RankedResume[];
}

interface RankingResultsProps {
  data: RankingData;
}

const RankingResults: React.FC<RankingResultsProps> = ({ data }) => {
  const [selectedResume, setSelectedResume] = useState<string | null>(null);
  const [resumeContent, setResumeContent] = useState<string>('');
  const [isViewingResume, setIsViewingResume] = useState(false);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="text-yellow-500" size={20} />;
      case 2:
        return <Medal className="text-gray-400" size={20} />;
      case 3:
        return <Award className="text-amber-600" size={20} />;
      default:
        return <span className="text-gray-500 font-bold">#{rank}</span>;
    }
  };

  const getMatchColor = (percentage: number) => {
    if (percentage >= 80) return 'text-green-600 bg-green-100';
    if (percentage >= 60) return 'text-yellow-600 bg-yellow-100';
    if (percentage >= 40) return 'text-orange-600 bg-orange-100';
    return 'text-red-600 bg-red-100';
  };

  const handleViewResume = async (resumeId: string) => {
    try {
      const response = await fetch(`http://localhost:3001/api/resume/${resumeId}`);
      const data = await response.json();
      
      if (data.success) {
        setResumeContent(data.resume.extractedText);
        setSelectedResume(resumeId);
        setIsViewingResume(true);
      }
    } catch (error) {
      console.error('Error fetching resume:', error);
    }
  };

  const generateReport = () => {
    const reportData = {
      generatedAt: new Date().toISOString(),
      jobDescription: data.jobDescription,
      totalResumes: data.totalResumes,
      rankings: data.rankings.map(r => ({
        rank: r.rank,
        fileName: r.originalName,
        matchPercentage: r.matchPercentage,
        uploadTime: r.uploadTime
      }))
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resume-ranking-report-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (isViewingResume) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-800">Resume Content</h3>
          <button
            onClick={() => setIsViewingResume(false)}
            className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            ← Back to Rankings
          </button>
        </div>
        <div className="p-6">
          <div className="bg-gray-50 rounded-lg p-4 max-h-96 overflow-y-auto">
            <pre className="whitespace-pre-wrap text-sm text-gray-700 font-mono">
              {resumeContent}
            </pre>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-800">Ranking Results</h2>
          <button
            onClick={generateReport}
            className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
          >
            <Download size={16} />
            Download Report
          </button>
        </div>
        <p className="text-gray-600 mt-2">
          Ranked {data.totalResumes} resumes based on job description match
        </p>
      </div>

      <div className="divide-y divide-gray-200">
        {data.rankings.map((resume) => (
          <div key={resume.id} className="p-6 hover:bg-gray-50 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-100">
                  {getRankIcon(resume.rank)}
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-900">{resume.originalName}</h3>
                  <p className="text-sm text-gray-500">
                    Uploaded {new Date(resume.uploadTime).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getMatchColor(resume.matchPercentage)}`}>
                    {resume.matchPercentage}% match
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {resume.textLength.toLocaleString()} characters
                  </p>
                </div>

                <button
                  onClick={() => handleViewResume(resume.id)}
                  className="flex items-center gap-1 px-3 py-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Eye size={16} />
                  View
                </button>
              </div>
            </div>

            {/* Progress bar */}
            <div className="mt-4">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${resume.matchPercentage}%` }}
                ></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {data.rankings.length === 0 && (
        <div className="p-8 text-center">
          <FileText className="mx-auto mb-4 text-gray-400" size={48} />
          <p className="text-gray-600">No resumes to display</p>
        </div>
      )}
    </div>
  );
};

export default RankingResults;