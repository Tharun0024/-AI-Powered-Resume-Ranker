import React, { useState } from 'react';
import { Upload, FileText, Trophy, Download, Trash2, Search, Users, Target } from 'lucide-react';
import FileUpload from './components/FileUpload';
import JobDescriptionInput from './components/JobDescriptionInput';
import RankingResults from './components/RankingResults';
import Header from './components/Header';
import StatsCard from './components/StatsCard';

interface Resume {
  id: string;
  originalName: string;
  uploadTime: string;
  textLength: number;
}

interface RankedResume extends Resume {
  rank: number;
  matchPercentage: number;
}

interface RankingData {
  success: boolean;
  jobDescription: string;
  totalResumes: number;
  rankings: RankedResume[];
}

function App() {
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [rankingData, setRankingData] = useState<RankingData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [jobDescription, setJobDescription] = useState('');

  const handleResumesUploaded = (uploadedResumes: Resume[]) => {
    setResumes(uploadedResumes);
    setRankingData(null); // Clear previous rankings
  };

  const handleRankingComplete = (data: RankingData) => {
    setRankingData(data);
  };

  const handleClearAll = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/resumes', {
        method: 'DELETE',
      });
      
      if (response.ok) {
        setResumes([]);
        setRankingData(null);
        setJobDescription('');
      }
    } catch (error) {
      console.error('Error clearing resumes:', error);
    }
  };

  const stats = [
    {
      title: 'Total Resumes',
      value: resumes.length.toString(),
      icon: FileText,
      color: 'blue'
    },
    {
      title: 'Job Matches',
      value: rankingData ? rankingData.rankings.filter(r => r.matchPercentage > 70).length.toString() : '0',
      icon: Target,
      color: 'green'
    },
    {
      title: 'Top Candidate',
      value: rankingData && rankingData.rankings.length > 0 ? `${rankingData.rankings[0].matchPercentage}%` : 'N/A',
      icon: Trophy,
      color: 'yellow'
    },
    {
      title: 'Processed',
      value: rankingData ? 'Complete' : resumes.length > 0 ? 'Ready' : 'Pending',
      icon: Users,
      color: 'purple'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <StatsCard key={index} {...stat} />
          ))}
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Upload & Job Description */}
          <div className="lg:col-span-1 space-y-6">
            <FileUpload 
              onResumesUploaded={handleResumesUploaded}
              isLoading={isLoading}
              setIsLoading={setIsLoading}
            />
            
            <JobDescriptionInput
              jobDescription={jobDescription}
              setJobDescription={setJobDescription}
              resumes={resumes}
              onRankingComplete={handleRankingComplete}
              isLoading={isLoading}
              setIsLoading={setIsLoading}
            />

            {resumes.length > 0 && (
              <button
                onClick={handleClearAll}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
              >
                <Trash2 size={20} />
                Clear All Resumes
              </button>
            )}
          </div>

          {/* Right Column - Results */}
          <div className="lg:col-span-2">
            {rankingData ? (
              <RankingResults data={rankingData} />
            ) : resumes.length > 0 ? (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
                <Search className="mx-auto mb-4 text-gray-400" size={48} />
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Ready to Rank</h3>
                <p className="text-gray-600">
                  {resumes.length} resume{resumes.length !== 1 ? 's' : ''} uploaded. 
                  Enter a job description to start ranking.
                </p>
              </div>
            ) : (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
                <Upload className="mx-auto mb-4 text-gray-400" size={48} />
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Get Started</h3>
                <p className="text-gray-600">
                  Upload PDF resumes to begin the AI-powered ranking process.
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;